import 'package:flutter/material.dart';
import 'dart:async';

void main() {
  runApp(QuizApp());
}

class QuizApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Quiz Uygulaması',
      home: QuizPage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class QuizPage extends StatefulWidget {
  @override
  _QuizPageState createState() => _QuizPageState();
}

class _QuizPageState extends State<QuizPage> {
  List<Question> questions = [
    Question('Türkiye’nin başkenti neresidir?', ['Ankara', 'İstanbul', 'İzmir', 'Bursa', 'Antalya'], 0),
    Question('Dart dili hangi firma tarafından geliştirilmiştir?', ['Microsoft', 'Facebook', 'Apple', 'Google', 'Amazon'], 3),
    Question('En büyük gezegen hangisidir?', ['Dünya', 'Venüs', 'Mars', 'Jüpiter', 'Satürn'], 3),
    Question('Flutter ile mobil uygulama hangi dille yazılır?', ['Java', 'Python', 'C++', 'Swift', 'Dart'], 4),
    Question('Türkiye kaç bölgeden oluşur?', ['5', '6', '7', '8', '9'], 2),
    Question('İlk 10 doğal sayı toplamı kaçtır?', ['40', '55', '60', '50', '45'], 1),
    Question('Hangisi bir programlama dili değildir?', ['Python', 'HTML', 'Java', 'C#', 'Swift'], 1),
    Question('Türk bayrağında hangi renk yoktur?', ['Kırmızı', 'Beyaz', 'Mavi', 'Yok', 'Hepsi var'], 2),
    Question('1 GB kaç MB\'dir?', ['1000', '1024', '512', '2048', '256'], 1),
    Question('Flutter hangi tür uygulama geliştirmeye uygundur?', ['Web', 'Mobil', 'Masaüstü', 'Hepsi', 'Hiçbiri'], 3),
  ];

  int currentQuestionIndex = 0;
  int score = 0;
  bool quizCompleted = false;
  bool quizStarted = false; // 👈 Yeni durum eklendi
  int timeLeft = 15;
  Timer? timer;

  void startTimer() {
    timer?.cancel();
    timeLeft = 15;
    timer = Timer.periodic(Duration(seconds: 1), (timer) {
      setState(() {
        if (timeLeft > 0) {
          timeLeft--;
        } else {
          timer.cancel();
          nextQuestion();
        }
      });
    });
  }

  void answerQuestion(int selectedIndex) {
    if (questions[currentQuestionIndex].correctIndex == selectedIndex) {
      score += 10;
    }
    nextQuestion();
  }

  void nextQuestion() {
    timer?.cancel();
    if (currentQuestionIndex < questions.length - 1) {
      setState(() {
        currentQuestionIndex++;
      });
      startTimer();
    } else {
      setState(() {
        quizCompleted = true;
      });
    }
  }

  void resetQuiz() {
    setState(() {
      currentQuestionIndex = 0;
      score = 0;
      quizCompleted = false;
      quizStarted = false;
    });
  }

  void startQuiz() {
    setState(() {
      quizStarted = true;
    });
    startTimer();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Quiz Uygulaması")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: quizStarted
            ? (quizCompleted
            ? Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text('Quiz Bitti!', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
              Text('Toplam Puanınız: $score', style: TextStyle(fontSize: 20)),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: resetQuiz,
                child: Text('Yeniden Başla'),
              )
            ],
          ),
        )
            : Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Soru ${currentQuestionIndex + 1}/${questions.length}', style: TextStyle(fontSize: 20)),
            Text('Kalan Süre: $timeLeft saniye', style: TextStyle(color: Colors.red)),
            SizedBox(height: 20),
            Text(questions[currentQuestionIndex].question, style: TextStyle(fontSize: 18)),
            SizedBox(height: 20),
            ...List.generate(5, (index) {
              return ElevatedButton(
                onPressed: () => answerQuestion(index),
                child: Text(questions[currentQuestionIndex].options[index]),
              );
            })
          ],
        ))
            : Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text("Sınava hazır mısın?", style: TextStyle(fontSize: 22)),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: startQuiz,
                child: Text("Başla"),
              )
            ],
          ),
        ),
      ),
    );
  }
}

class Question {
  final String question;
  final List<String> options;
  final int correctIndex;

  Question(this.question, this.options, this.correctIndex);
}
