package com.example.mervenuryalcin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
